package exercise.junitmavenexample;

public class Main {	
	public static void main(String[] args) throws Exception {
		Calculator calculator = new Calculator();
		System.out.println(calculator.addition(10.0, 20.0));
		System.out.println(calculator.subtraction(10.0, 20.0));
		System.out.println(calculator.multiplication(10.0, 20.0));
		System.out.println(calculator.divison(10.0, 20.0));
		

	}
}
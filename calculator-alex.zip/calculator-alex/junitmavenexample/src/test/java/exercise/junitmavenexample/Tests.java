package exercise.junitmavenexample;

import org.junit.Test;

import junit.framework.Assert;


public class Tests {
	Calculator cal = new Calculator();
	
	
	@Test
	public void addition() {
		Assert.assertEquals("Test failed", 4.0, cal.addition(2.0, 2.0),0.01d);
	}

	@Test
	public void addition2() {
		Assert.assertEquals("Test failed", 6.0, cal.addition(2.0, 4.0),0.01d);
	}
	
	@Test
	public void addition3() {
		Assert.assertEquals("Test failed", 8.0, cal.addition(4.0, 4.0),0.01d);
	}
	
	@Test
	public void subtraction() {
		Assert.assertEquals("Test failed", 2.0, cal.subtraction(4.0, 2.0),0.01d);
	}
	
	@Test
	public void subtraction2(){
		Assert.assertEquals("Test failed", 6.0, cal.subtraction(8.0, 2.0),0.01d);
	}
	
	@Test
	public void subtraction3(){
		Assert.assertEquals("Test failed", 4.0, cal.subtraction(8.0, 4.0),0.01d);
	}
	
	@Test
	public void multiplication(){
		Assert.assertEquals("Test failed", 4.0, cal.multiplication(2.0, 2.0),0.01d);
	}
	
	@Test
	public void multiplication2(){
		Assert.assertEquals("Test failed", 9.0, cal.multiplication(3.0, 3.0),0.01d);
	}
	
	@Test
	public void multiplication3(){
		Assert.assertEquals("Test failed", 8.0, cal.multiplication(4.0, 2.0),0.01d);
	}
	
	@Test
	public void division() throws Exception{
		Assert.assertEquals("Test failed", 1.0, cal.divison(2.0, 2.0),0.01d);
	}
	
	@Test
	public void division2() throws Exception{
		Assert.assertEquals("Test failed", 2.0, cal.divison(4.0, 2.0),0.01d);
	}
	
	@Test
	public void division3() throws Exception{
		Assert.assertEquals("Test failed", 3.0, cal.divison(6.0, 2.0),0.01d);
	}
}
